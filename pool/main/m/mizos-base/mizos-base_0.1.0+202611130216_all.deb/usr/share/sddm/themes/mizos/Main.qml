// MizOS: tela de entrada no estilo do Windows 11.
import QtQuick

Rectangle {
    id: raiz
    width: 1920
    height: 1080
    color: "#202020"

    readonly property int usuarioAtual: userModel.lastIndex >= 0 ? userModel.lastIndex : 0
    readonly property string fonte: "Selawik"

    function entrar() {
        erro.text = ""
        sddm.login(nomeLogin.text, senha.text, sessionModel.lastIndex >= 0 ? sessionModel.lastIndex : 0)
    }

    Image {
        anchors.fill: parent
        source: config.background
        fillMode: Image.PreserveAspectCrop
        asynchronous: true
    }
    Rectangle { anchors.fill: parent; color: "#000000"; opacity: 0.45 }

    // Pega o usuário da última sessão (nome de login e nome completo)
    Repeater {
        model: userModel
        delegate: Item {
            visible: false
            Component.onCompleted: {
                if (index === raiz.usuarioAtual) {
                    nomeLogin.text = name
                    nomeVisivel.text = realName !== "" ? realName : name
                }
            }
        }
    }
    Text { id: nomeLogin; visible: false }

    Column {
        anchors.centerIn: parent
        anchors.verticalCenterOffset: -40
        spacing: 20
        width: 320

        Rectangle {
            width: 168; height: 168; radius: 84
            anchors.horizontalCenter: parent.horizontalCenter
            color: "#2bffffff"
            border.color: "#40ffffff"
            Text {
                anchors.centerIn: parent
                text: nomeVisivel.text.length > 0 ? nomeVisivel.text.charAt(0).toUpperCase() : "M"
                color: "#ffffff"
                font.family: raiz.fonte
                font.pixelSize: 64
                font.weight: Font.DemiBold
            }
        }

        Text {
            id: nomeVisivel
            anchors.horizontalCenter: parent.horizontalCenter
            color: "#ffffff"
            font.family: raiz.fonte
            font.pixelSize: 28
            font.weight: Font.DemiBold
        }

        // Campo de senha: fundo translúcido, linha de destaque embaixo e seta
        Rectangle {
            width: 300; height: 36; radius: 4
            anchors.horizontalCenter: parent.horizontalCenter
            color: senha.activeFocus ? "#33000000" : "#22ffffff"
            border.color: "#40ffffff"

            TextInput {
                id: senha
                anchors.left: parent.left
                anchors.right: botaoEntrar.left
                anchors.verticalCenter: parent.verticalCenter
                anchors.leftMargin: 12
                anchors.rightMargin: 8
                echoMode: TextInput.Password
                passwordCharacter: "●"
                color: "#ffffff"
                selectionColor: "#ffffff"
                selectedTextColor: "#000000"
                font.family: raiz.fonte
                font.pixelSize: 15
                focus: true
                clip: true
                Keys.onReturnPressed: raiz.entrar()
                Keys.onEnterPressed: raiz.entrar()
            }
            Text {
                anchors.left: parent.left
                anchors.leftMargin: 12
                anchors.verticalCenter: parent.verticalCenter
                text: "Senha"
                color: "#b0ffffff"
                font.family: raiz.fonte
                font.pixelSize: 15
                visible: senha.text.length === 0
            }
            Rectangle {
                anchors.bottom: parent.bottom
                anchors.left: parent.left
                anchors.right: parent.right
                anchors.margins: 1
                height: 2
                color: "#ffffff"
                visible: senha.activeFocus
            }
            Rectangle {
                id: botaoEntrar
                width: 28; height: 28; radius: 4
                anchors.right: parent.right
                anchors.rightMargin: 4
                anchors.verticalCenter: parent.verticalCenter
                color: areaEntrar.containsMouse ? "#33ffffff" : "transparent"
                Text {
                    anchors.centerIn: parent
                    text: "→"
                    color: "#ffffff"
                    font.family: raiz.fonte
                    font.pixelSize: 18
                }
                MouseArea { id: areaEntrar; anchors.fill: parent; hoverEnabled: true; onClicked: raiz.entrar() }
            }
        }

        Text {
            id: erro
            anchors.horizontalCenter: parent.horizontalCenter
            color: "#ffffff"
            font.family: raiz.fonte
            font.pixelSize: 14
        }
    }

    // Relógio, como na tela de bloqueio do Windows
    Column {
        anchors.left: parent.left
        anchors.bottom: parent.bottom
        anchors.margins: 48
        spacing: 2
        Text {
            id: hora
            color: "#ffffff"
            font.family: raiz.fonte
            font.pixelSize: 72
            font.weight: Font.DemiBold
        }
        Text {
            id: data
            color: "#ffffff"
            font.family: raiz.fonte
            font.pixelSize: 22
        }
        Timer {
            interval: 1000; running: true; repeat: true; triggeredOnStart: true
            onTriggered: {
                var agora = new Date()
                hora.text = Qt.formatTime(agora, "HH:mm")
                data.text = agora.toLocaleDateString(Qt.locale("pt_BR"), "dddd, d 'de' MMMM")
            }
        }
    }

    // Energia, no canto como no Windows
    Row {
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 32
        spacing: 6
        Repeater {
            model: [
                { rotulo: "Reiniciar", acao: function() { sddm.reboot() }, ativo: sddm.canReboot },
                { rotulo: "Desligar", acao: function() { sddm.powerOff() }, ativo: sddm.canPowerOff }
            ]
            delegate: Rectangle {
                width: rotuloEnergia.implicitWidth + 28; height: 34; radius: 4
                visible: modelData.ativo
                color: areaEnergia.containsMouse ? "#33ffffff" : "#18ffffff"
                Text {
                    id: rotuloEnergia
                    anchors.centerIn: parent
                    text: modelData.rotulo
                    color: "#ffffff"
                    font.family: raiz.fonte
                    font.pixelSize: 14
                }
                MouseArea { id: areaEnergia; anchors.fill: parent; hoverEnabled: true; onClicked: modelData.acao() }
            }
        }
    }

    Connections {
        target: sddm
        function onLoginFailed() {
            erro.text = "Senha incorreta. Tente de novo."
            senha.text = ""
            senha.forceActiveFocus()
        }
    }
}
