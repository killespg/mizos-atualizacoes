#!/bin/sh
# MizOS: instala a família Fluent (visual do Windows 11, GPL-3) na variante
# cinza, que combina com o MizOS monocromático:
#   - ícones   -> /usr/share/icons/Fluent-grey{,-dark}
#   - GTK      -> /usr/share/themes/Fluent-grey-*
#   - Kvantum  -> /usr/share/Kvantum/Fluent-grey (apps Qt)
# Versões fixas para o build da ISO sair sempre igual.
# Precisa de: git, sassc.
set -e

ICONES_TAG=2026-07-27
GTK_TAG=2025-04-17
KDE_TAG=2021-11-04
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT

git -c advice.detachedHead=false clone -q --depth 1 -b "$ICONES_TAG" https://github.com/vinceliuice/Fluent-icon-theme.git "$TMP/icones"
(cd "$TMP/icones" && ./install.sh -d /usr/share/icons grey >/dev/null)

git -c advice.detachedHead=false clone -q --depth 1 -b "$GTK_TAG" https://github.com/vinceliuice/Fluent-gtk-theme.git "$TMP/gtk"
(cd "$TMP/gtk" && ./install.sh -d /usr/share/themes -t grey --tweaks round >/dev/null)

git -c advice.detachedHead=false clone -q --depth 1 -b "$KDE_TAG" https://github.com/vinceliuice/Fluent-kde.git "$TMP/kde"
mkdir -p /usr/share/Kvantum
cp -r "$TMP/kde/Kvantum/Fluent-grey" /usr/share/Kvantum/
# O tema foi feito para compositores com desfoque; sem desfoque, janela
# translúcida deixa ver o que está atrás. No MizOS, janelas sólidas.
for kv in /usr/share/Kvantum/Fluent-grey/*.kvconfig; do
	sed -i -e 's/^translucent_windows=true/translucent_windows=false/' \
		-e 's/^blurring=true/blurring=false/' \
		-e 's/^popup_blurring=true/popup_blurring=false/' \
		-e 's/^reduce_window_opacity=.*/reduce_window_opacity=0/' \
		-e 's/^reduce_menu_opacity=.*/reduce_menu_opacity=0/' "$kv"
done

gtk-update-icon-cache -f /usr/share/icons/Fluent-grey 2>/dev/null || true
gtk-update-icon-cache -f /usr/share/icons/Fluent-grey-dark 2>/dev/null || true
echo "MizOS: Fluent (cinza) instalado"
