#!/bin/sh
# MizOS: gera o tema de cursores "MizOS" (formato Xcursor) a partir dos SVGs.
# Uso: gerar.sh [pasta-de-destino]   (padrão: /usr/share/icons/MizOS)
# Precisa de: rsvg-convert (librsvg2-bin) e xcursorgen (x11-apps).
set -e

SRC=$(cd "$(dirname "$0")" && pwd)
DEST=${1:-/usr/share/icons/MizOS}
TAMANHOS="24 32 48 64"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$DEST/cursors"

# gerar NOME ARQUIVO.svg X Y [QUADROS] [ANGULO]
#   X Y     = ponto do clique, na grade de 32 px
#   QUADROS = mais de 1 gira o desenho (cursor animado de espera)
#   ANGULO  = rotação fixa (setas de redimensionar)
gerar() {
	nome=$1 svg=$2 hx=$3 hy=$4 quadros=${5:-1} angulo=${6:-0}
	: > "$TMP/$nome.cfg"
	for t in $TAMANHOS; do
		x=$((hx * t / 32))
		y=$((hy * t / 32))
		i=0
		while [ "$i" -lt "$quadros" ]; do
			if [ "$quadros" -gt 1 ]; then
				ang=$((i * 360 / quadros))
				atraso=" 60"
			else
				ang=$angulo
				atraso=""
			fi
			sed "s/ANGULO/$ang/g" "$SRC/$svg" > "$TMP/quadro.svg"
			png="$TMP/$nome-$t-$i.png"
			rsvg-convert -w "$t" -h "$t" "$TMP/quadro.svg" -o "$png"
			echo "$t $x $y $png$atraso" >> "$TMP/$nome.cfg"
			i=$((i + 1))
		done
	done
	xcursorgen "$TMP/$nome.cfg" "$DEST/cursors/$nome"
}

# apelidos ALVO NOME... : outros nomes que os apps usam para o mesmo cursor
apelidos() {
	alvo=$1
	shift
	for a in "$@"; do
		ln -sf "$alvo" "$DEST/cursors/$a"
	done
}

gerar default seta.svg 2 2
apelidos default left_ptr arrow top_left_arrow

gerar pointer mao.svg 10 2
apelidos pointer hand hand1 hand2 pointing_hand grab openhand grabbing closedhand dnd-move \
	e29285e634086352946a0e7090d73106 9d800788f1b08800ae810202380a0822

gerar text texto.svg 16 16
apelidos text xterm ibeam vertical-text

gerar wait espera.svg 16 16 12
apelidos wait watch

gerar progress progresso.svg 2 2 12
apelidos progress left_ptr_watch half-busy 08e8e1c95fe2fc01f976f1e063a24ccd 3ecb610c1bf2410f44200f48c40d3599

gerar not-allowed proibido.svg 16 16
apelidos not-allowed crossed_circle forbidden no-drop circle 03b6e0fcb3499374a867c041f52298f0

gerar crosshair mira.svg 16 16
apelidos crosshair cross tcross cell

gerar move mover.svg 16 16
apelidos move fleur size_all all-scroll 4498f0e0c1937ffe01fd06f973665830 9081237383d90e509aa00f00170e968f

gerar help ajuda.svg 2 2
apelidos help question_arrow whats_this left_ptr_help d9ce0ab605698f320427677b458ad60b 5c6cd98b3f3ebcb1f9c7f1c204630408

gerar ew-resize redimensionar.svg 16 16 1 0
apelidos ew-resize e-resize w-resize left_side right_side size_hor h_double_arrow sb_h_double_arrow \
	col-resize 028006030e0e7ebffc7f7070c0600140

gerar ns-resize redimensionar.svg 16 16 1 90
apelidos ns-resize n-resize s-resize top_side bottom_side size_ver v_double_arrow sb_v_double_arrow \
	row-resize 00008160000006810000408080010102

gerar nwse-resize redimensionar.svg 16 16 1 45
apelidos nwse-resize nw-resize se-resize top_left_corner bottom_right_corner size_fdiag bd_double_arrow \
	c7088f0f3e6c8088236ef8e1e3e70000

gerar nesw-resize redimensionar.svg 16 16 1 -45
apelidos nesw-resize ne-resize sw-resize top_right_corner bottom_left_corner size_bdiag fd_double_arrow \
	fcf1c3c7cd4491d801f1e1c78f100000

cat > "$DEST/index.theme" <<EOF
[Icon Theme]
Name=MizOS
Comment=Cursores do MizOS no estilo do Windows 11
Inherits=breeze_cursors
EOF

echo "MizOS: cursores gerados em $DEST"
